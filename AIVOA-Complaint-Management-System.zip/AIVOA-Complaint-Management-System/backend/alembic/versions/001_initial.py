"""Initial QMS schema."""
from alembic import op
import sqlalchemy as sa
revision = '001'
down_revision = None
branch_labels = None
depends_on = None
def upgrade():
    op.create_table('complaints', sa.Column('id',sa.Integer,primary_key=True), sa.Column('status',sa.String(32),nullable=False), sa.Column('complaint_source',sa.String(100)), sa.Column('customer_name',sa.String(255)), sa.Column('product_name',sa.String(255)), sa.Column('batch_lot_number',sa.String(100)), sa.Column('product_strength_grade',sa.String(100)), sa.Column('affected_quantity',sa.Integer), sa.Column('affected_quantity_unit',sa.String(40)), sa.Column('manufacturing_date',sa.String(20)), sa.Column('expiry_date',sa.String(20)), sa.Column('originating_site_block',sa.String(255)), sa.Column('impacted_non_product_materials',sa.Text), sa.Column('structured_defect_summary',sa.Text), sa.Column('complaint_category',sa.String(100)), sa.Column('complaint_description',sa.Text), sa.Column('complaint_date',sa.String(20)), sa.Column('initial_severity',sa.String(20)), sa.Column('priority',sa.String(20)), sa.Column('created_at',sa.DateTime), sa.Column('updated_at',sa.DateTime), sa.Column('committed_at',sa.DateTime))
    op.create_table('complaint_analysis',sa.Column('id',sa.Integer,primary_key=True),sa.Column('complaint_id',sa.Integer,sa.ForeignKey('complaints.id')),sa.Column('completeness_score',sa.Float),sa.Column('missing_fields',sa.JSON),sa.Column('risk',sa.JSON),sa.Column('duplicates',sa.JSON),sa.Column('recommendations',sa.JSON))
    op.create_table('audit_events',sa.Column('id',sa.Integer,primary_key=True),sa.Column('complaint_id',sa.Integer,sa.ForeignKey('complaints.id')),sa.Column('event_type',sa.String(64)),sa.Column('details',sa.JSON),sa.Column('created_at',sa.DateTime))
def downgrade():
    op.drop_table('audit_events')
    op.drop_table('complaint_analysis')
    op.drop_table('complaints')
