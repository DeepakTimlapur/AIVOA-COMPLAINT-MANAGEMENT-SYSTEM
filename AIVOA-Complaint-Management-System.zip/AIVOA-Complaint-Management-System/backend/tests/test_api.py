import os
os.environ['DATABASE_URL'] = 'sqlite:///./test.db'
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine
Base.metadata.create_all(engine)
client = TestClient(app)

def test_health():
    assert client.get('/health').json()['status'] == 'ok'

def test_committed_is_read_only():
    c = client.post('/api/complaints', json={'product_name':'X','batch_lot_number':'B1','complaint_description':'broken tablets'}).json()
    assert client.post(f"/api/complaints/{c['id']}/commit", json={'confirm':True}).status_code == 200
    assert client.patch(f"/api/complaints/{c['id']}", json={'customer_name':'No'}).status_code == 409
