from fastapi.testclient import TestClient
from app.main import app
from app.database import Base,engine
from app.models import AuditEvent, ComplaintAnalysis
from app.database import SessionLocal
Base.metadata.create_all(engine)

def test_api_workflow_and_persistence():
 with TestClient(app) as client:
  assert client.post('/api/complaints/extract',json={'source_text':'Apollo Pharmacy reported discolored capsules.'}).status_code == 200
  created=client.post('/api/complaints',json={'product_name':'Amoxicillin Capsules','complaint_description':'Discolored capsules','batch_lot_number':'OLD_BATCH','affected_quantity':20}).json(); cid=created['id']
  assert client.get(f'/api/complaints/{cid}').status_code == 200
  assert client.patch(f'/api/complaints/{cid}',json={'customer_name':'Apollo Pharmacy'}).json()['customer_name']=='Apollo Pharmacy'
  patch=client.post(f'/api/complaints/{cid}/copilot',json={'message':'Sorry, the batch number is BMX240602 and affected quantity is 48 capsules.'}).json()
  assert patch['updates']=={'batch_lot_number':'BMX240602','affected_quantity':48,'affected_quantity_unit':'capsules'}
  for path in ('completeness','risk','duplicate-check','recommendations','summary'):
   assert client.post(f'/api/complaints/{cid}/{path}').status_code == 200
  db=SessionLocal()
  try:
   assert db.query(ComplaintAnalysis).filter_by(complaint_id=cid).one().risk
   assert db.query(AuditEvent).filter_by(complaint_id=cid,event_type='FIELD_UPDATED').count()==1
  finally: db.close()

def test_api_failures():
 with TestClient(app) as client:
  assert client.get('/api/complaints/999999').status_code == 404
  assert client.post('/api/complaints/extract',json={'source_text':'x'}).status_code == 422
  assert client.post('/api/complaints/extract-document',files={'file':('bad.exe',b'x','application/octet-stream')}).status_code == 422
  c=client.post('/api/complaints',json={'product_name':'X','complaint_description':'Broken tablet'}).json()
  assert client.post(f"/api/complaints/{c['id']}/commit",json={'confirm':True}).status_code==422
