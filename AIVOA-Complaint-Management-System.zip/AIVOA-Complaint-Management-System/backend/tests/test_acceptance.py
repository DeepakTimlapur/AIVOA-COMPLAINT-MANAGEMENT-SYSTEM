from fastapi.testclient import TestClient
from app.main import app

def test_acceptance_path_without_live_groq():
 """Exercises every deterministic stage; live Groq is separately env-gated."""
 with TestClient(app) as client:
  intake=client.post('/api/complaints/extract',json={'source_text':'Apollo Pharmacy reported discolored capsules in Amoxicillin Capsules 500 mg.'})
  assert intake.status_code==200 and intake.json()['analysis']['risk']['suggested_next_action']
  c=client.post('/api/complaints',json={'customer_name':'Apollo Pharmacy','product_name':'Amoxicillin Capsules','product_strength_grade':'500 mg','complaint_description':'Discolored capsules'}).json();cid=c['id']
  assert client.post(f'/api/complaints/{cid}/completeness').json()['missing_fields']
  before=client.get(f'/api/complaints/{cid}').json()
  patch=client.post(f'/api/complaints/{cid}/copilot',json={'message':'Sorry, the batch number is BMX240602 and affected quantity is 48 capsules.'}).json()['updates']
  assert patch=={'batch_lot_number':'BMX240602','affected_quantity':48,'affected_quantity_unit':'capsules'}
  after=client.get(f'/api/complaints/{cid}').json();assert after['product_name']==before['product_name'] and after['customer_name']==before['customer_name']
  for endpoint in ('completeness','risk','duplicate-check','recommendations','summary'): assert client.post(f'/api/complaints/{cid}/{endpoint}').status_code==200
  assert client.post(f'/api/complaints/{cid}/commit',json={'confirm':True}).status_code==200
  assert client.get(f'/api/complaints/{cid}').json()['status']=='Committed'
  assert client.patch(f'/api/complaints/{cid}',json={'customer_name':'Changed'}).status_code==409
