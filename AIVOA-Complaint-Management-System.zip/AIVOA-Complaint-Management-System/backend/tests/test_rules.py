from app.schemas import ComplaintFields
from app.services.rules import completeness, risk, commit_eligibility
from app.services.copilot import intent, update_patch

def test_completeness_and_commit_gating():
    c = ComplaintFields(product_name='Amoxicillin', complaint_description='Discolored capsules')
    assert completeness(c)['missing_fields']
    assert not commit_eligibility(c)['eligible']

def test_risk_is_transparent():
    r = risk(ComplaintFields(complaint_description='Foreign matter contamination affecting patient'))
    assert r['suggested_severity'] == 'High'

def test_conversational_patch_preserves_unrelated_fields():
    original = {'product_name':'Amoxicillin','complaint_description':'Discolored','batch_lot_number':'OLD_BATCH','affected_quantity':20}
    patch = update_patch('Sorry, the batch number is BMX240602 and affected quantity is 48 capsules')
    merged = {**original, **patch.updates.model_dump(exclude_none=True)}
    assert merged['batch_lot_number'] == 'BMX240602'
    assert merged['affected_quantity'] == 48
    assert merged['affected_quantity_unit'] == 'capsules'
    assert merged['product_name'] == 'Amoxicillin'

def test_intent():
    assert intent('sorry, the batch number is ABC') == 'UPDATE_FIELD'
