from io import BytesIO
from docx import Document
from pypdf import PdfWriter
from app.services.documents import extract_text, DocumentError, MAX_UPLOAD_BYTES
def test_txt_parsing(): assert extract_text('complaint.txt','text/plain',b'Broken tablets') == 'Broken tablets'
def test_eml_parsing(): assert 'Discolored' in extract_text('c.eml','message/rfc822',b'Subject: Complaint\n\nDiscolored capsules')
def test_docx_parsing():
 d=Document();d.add_paragraph('Amoxicillin issue');out=BytesIO();d.save(out)
 assert 'Amoxicillin' in extract_text('c.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',out.getvalue())
def test_upload_validation():
 try: extract_text('../bad.txt','text/plain',b'x')
 except DocumentError as exc: assert 'Unsafe' in str(exc)
 else: assert False
def test_image_only_pdf_explains_ocr_limit():
 writer=PdfWriter();writer.add_blank_page(width=100,height=100);data=BytesIO();writer.write(data)
 try: extract_text('scan.pdf','application/pdf',data.getvalue())
 except DocumentError as exc: assert 'OCR is not supported' in str(exc)
 else: assert False
 try: extract_text('large.txt','text/plain',b'x'*(MAX_UPLOAD_BYTES+1))
 except DocumentError as exc: assert '10 MB' in str(exc)
 else: assert False
