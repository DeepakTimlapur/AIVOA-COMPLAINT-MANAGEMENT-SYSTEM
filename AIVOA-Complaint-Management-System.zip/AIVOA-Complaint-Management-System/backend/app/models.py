from datetime import datetime
from sqlalchemy import String, Text, Integer, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class Complaint(Base):
    __tablename__ = "complaints"
    id: Mapped[int] = mapped_column(primary_key=True)
    status: Mapped[str] = mapped_column(String(32), default="Pending Triage", index=True)
    complaint_source: Mapped[str|None] = mapped_column(String(100), nullable=True)
    customer_name: Mapped[str|None] = mapped_column(String(255), nullable=True, index=True)
    product_name: Mapped[str|None] = mapped_column(String(255), nullable=True, index=True)
    batch_lot_number: Mapped[str|None] = mapped_column(String(100), nullable=True, index=True)
    product_strength_grade: Mapped[str|None] = mapped_column(String(100), nullable=True)
    affected_quantity: Mapped[int|None] = mapped_column(Integer, nullable=True)
    affected_quantity_unit: Mapped[str|None] = mapped_column(String(40), nullable=True)
    manufacturing_date: Mapped[str|None] = mapped_column(String(20), nullable=True)
    expiry_date: Mapped[str|None] = mapped_column(String(20), nullable=True)
    originating_site_block: Mapped[str|None] = mapped_column(String(255), nullable=True)
    impacted_non_product_materials: Mapped[str|None] = mapped_column(Text, nullable=True)
    structured_defect_summary: Mapped[str|None] = mapped_column(Text, nullable=True)
    complaint_category: Mapped[str|None] = mapped_column(String(100), nullable=True, index=True)
    complaint_description: Mapped[str|None] = mapped_column(Text, nullable=True)
    complaint_date: Mapped[str|None] = mapped_column(String(20), nullable=True)
    initial_severity: Mapped[str|None] = mapped_column(String(20), nullable=True)
    priority: Mapped[str|None] = mapped_column(String(20), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    committed_at: Mapped[datetime|None] = mapped_column(DateTime, nullable=True)
    analyses = relationship("ComplaintAnalysis", cascade="all, delete-orphan")

class ComplaintAnalysis(Base):
    __tablename__ = "complaint_analysis"
    id: Mapped[int] = mapped_column(primary_key=True)
    complaint_id: Mapped[int] = mapped_column(ForeignKey("complaints.id"), index=True)
    completeness_score: Mapped[float|None] = mapped_column(Float, nullable=True)
    missing_fields: Mapped[list] = mapped_column(JSON, default=list)
    risk: Mapped[dict] = mapped_column(JSON, default=dict)
    duplicates: Mapped[list] = mapped_column(JSON, default=list)
    recommendations: Mapped[dict] = mapped_column(JSON, default=dict)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    complaint_id: Mapped[int] = mapped_column(ForeignKey("complaints.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
