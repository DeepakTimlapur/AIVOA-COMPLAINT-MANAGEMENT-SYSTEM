from typing import TypedDict, Any
from langgraph.graph import StateGraph, START, END
from .schemas import ComplaintFields
from .services.rules import completeness, risk
from .services.copilot import intent, update_patch
class ComplaintState(TypedDict, total=False):
    source_text:str; complaint:dict; missing_fields:list; completeness_score:float; risk_assessment:dict; duplicate_matches:list; user_intent:str; requested_field_updates:dict; response:str; warnings:list; processing_stage:str
def validate_input(s): return {"processing_stage":"validated"}
def extract_complaint(s): return {"complaint":{"complaint_description":s["source_text"]},"processing_stage":"extracted"}
def calc_complete(s):
    x=completeness(s["complaint"]); return {**x,"processing_stage":"completeness"}
def assess_risk(s): return {"risk_assessment":risk(s["complaint"]),"processing_stage":"risk"}
def duplicate(s): return {"duplicate_matches":[],"processing_stage":"duplicate_check"}
g=StateGraph(ComplaintState); g.add_node("validate_input",validate_input);g.add_node("extract_complaint",extract_complaint);g.add_node("calculate_completeness",calc_complete);g.add_node("risk_assessment",assess_risk);g.add_node("duplicate_check",duplicate)
g.add_edge(START,"validate_input");g.add_edge("validate_input","extract_complaint");g.add_edge("extract_complaint","calculate_completeness");g.add_edge("calculate_completeness","risk_assessment");g.add_edge("risk_assessment","duplicate_check");g.add_edge("duplicate_check",END);extract_and_analyze_graph=g.compile()
def detect(s): return {"user_intent":intent(s["source_text"])}
def copilot_update(s):
    p=update_patch(s["source_text"]); return {"requested_field_updates":p.updates.model_dump(exclude_none=True),"response":p.response}
def compose(s): return {"response": s.get("response") or f"{s['user_intent']} request prepared for deterministic backend review."}
def route(s): return "update_field" if s['user_intent']=="UPDATE_FIELD" else "compose_response"
cg=StateGraph(ComplaintState);cg.add_node("detect_intent",detect);cg.add_node("update_field",copilot_update);cg.add_node("compose_response",compose);cg.add_edge(START,"detect_intent");cg.add_conditional_edges("detect_intent",route,{"update_field":"update_field","compose_response":"compose_response"});cg.add_edge("update_field","compose_response");cg.add_edge("compose_response",END);copilot_graph=cg.compile()
