from datetime import datetime
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from .database import Base,engine,get_db
from .models import Complaint, ComplaintAnalysis, AuditEvent
from .schemas import *
from .services.rules import completeness,risk,commit_eligibility
from .services.analysis import duplicates, recommendations, summary, persist_analysis
from .services.copilot import intent,update_patch
from .services.groq import extract_complaint as groq_extract
from .graphs import extract_and_analyze_graph, copilot_graph
from .services.documents import extract_text, DocumentError
app=FastAPI(title="AIVOA Complaint QMS")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_methods=["*"],allow_headers=["*"])
def audit(db,cid,event,details={}): db.add(AuditEvent(complaint_id=cid,event_type=event,details=details))
def obj(c): return ComplaintOut.model_validate(c)
@app.get("/health")
def health(): return {"status":"ok"}
@app.post("/api/complaints",response_model=ComplaintOut)
def create(body:ComplaintCreate,db:Session=Depends(get_db)):
 c=Complaint(**body.model_dump());db.add(c);db.flush();audit(db,c.id,"COMPLAINT_CREATED");db.commit();db.refresh(c);return obj(c)
@app.get("/api/complaints",response_model=list[ComplaintOut])
def list_(db:Session=Depends(get_db)): return [obj(c) for c in db.scalars(select(Complaint).order_by(Complaint.created_at.desc())).all()]
@app.get("/api/complaints/{cid}",response_model=ComplaintOut)
def get(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 return obj(c)
@app.patch("/api/complaints/{cid}",response_model=ComplaintOut)
def patch(cid:int,body:ComplaintPatch,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 if c.status=="Committed": raise HTTPException(409,"Committed complaints are read-only")
 changes=body.model_dump(exclude_unset=True)
 for k,v in changes.items(): setattr(c,k,v)
 audit(db,cid,"USER_EDIT",{"fields":list(changes)});db.commit();db.refresh(c);return obj(c)
@app.post("/api/complaints/extract")
async def extract(body:ExtractRequest):
 # LangGraph provides the controlled intake pipeline; Groq supplies validated facts.
 graph_result = extract_and_analyze_graph.invoke({"source_text": body.source_text})
 try:
  data = await groq_extract(body.source_text)
  warning = None
 except RuntimeError as exc:
  data = ComplaintFields(complaint_description=body.source_text)
  warning = f"AI extraction unavailable: {exc}. Raw complaint retained; no facts were inferred."
 return {"complaint":data,"analysis":{**completeness(data),"risk":risk(data),"intake_stage":graph_result.get("processing_stage")},"warning":warning}
@app.post("/api/complaints/extract-document")
async def extract_document(file: UploadFile = File(...)):
 try:
  text = extract_text(file.filename or '', file.content_type, await file.read())
 except DocumentError as exc:
  raise HTTPException(422, str(exc))
 return await extract(ExtractRequest(source_text=text))
@app.post("/api/complaints/{cid}/copilot")
def copilot(cid:int,body:CopilotRequest,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 if c.status=="Committed": raise HTTPException(409,"Committed complaints are read-only")
 graph = copilot_graph.invoke({"source_text":body.message})
 i=graph["user_intent"]; p=update_patch(body.message) if i=="UPDATE_FIELD" else None
 if p:
  updates=p.updates.model_dump(exclude_none=True)
  for k,v in updates.items(): setattr(c,k,v)
  audit(db,cid,"FIELD_UPDATED",{"fields":list(updates),"source":"copilot"});db.commit()
  return {"intent":i,"updates":updates,"response":p.response}
 if i=="COMPLETENESS_CHECK": return {"intent":i,"updates":{},"analysis":complete(cid,db),"response":"Completeness has been checked against deterministic required fields."}
 if i=="RISK_ASSESSMENT": return {"intent":i,"updates":{},"analysis":risk_(cid,db),"response":"Risk is a deterministic advisory assessment."}
 if i=="DUPLICATE_CHECK": return {"intent":i,"updates":{},"analysis":duplicate_check(cid,db),"response":"Duplicate candidates were checked without an LLM call."}
 if i in ("ROOT_CAUSE","CAPA"):
  data=recommendations(c); persist_analysis(db,cid,recommendations=data); audit(db,cid,"AI_RECOMMENDATIONS",{"type":i});db.commit()
  return {"intent":i,"updates":{},"analysis":data,"response":data['disclaimer']}
 if i=="SUMMARY": return {"intent":i,"updates":{},"analysis":{"summary":summary(c)},"response":"Summary is grounded in known fields only."}
 if i=="COMMIT_REQUEST": return {"intent":i,"updates":{},"analysis":commit_eligibility(obj(c)),"response":"AI cannot commit. A qualified human must explicitly confirm an eligible record."}
 return {"intent":i,"updates":{},"response":graph['response']}
@app.post("/api/complaints/{cid}/completeness")
def complete(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid) or (_ for _ in ()).throw(HTTPException(404,"Complaint not found")); data=completeness(obj(c));persist_analysis(db,cid,completeness_score=data['completeness_score'],missing_fields=data['missing_fields']);audit(db,cid,"COMPLETENESS_CHECK",data);db.commit();return data
@app.post("/api/complaints/{cid}/risk")
def risk_(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid) or (_ for _ in ()).throw(HTTPException(404,"Complaint not found")); r=risk(obj(c));persist_analysis(db,cid,risk=r);audit(db,cid,"AI_RISK_ASSESSMENT",r);db.commit();return r
@app.post("/api/complaints/{cid}/duplicate-check")
def duplicate_check(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 data=duplicates(db,c);persist_analysis(db,cid,duplicates=data);audit(db,cid,"DUPLICATE_CHECK",{"count":len(data)});db.commit();return {"possible_duplicates":data}
@app.post("/api/complaints/{cid}/recommendations")
def recommendation(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 data=recommendations(c);persist_analysis(db,cid,recommendations=data);audit(db,cid,"AI_RECOMMENDATIONS",{});db.commit();return data
@app.post("/api/complaints/{cid}/summary")
def summary_(cid:int,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 data={"summary":summary(c)};persist_analysis(db,cid,recommendations={"summary":data["summary"]});audit(db,cid,"SUMMARY_GENERATED",{});db.commit();return data
@app.post("/api/complaints/{cid}/commit")
def commit(cid:int,body:CommitRequest,db:Session=Depends(get_db)):
 c=db.get(Complaint,cid)
 if not c: raise HTTPException(404,"Complaint not found")
 if c.status=="Committed": raise HTTPException(409,"Already committed")
 gate=commit_eligibility(obj(c))
 if not gate["eligible"]: raise HTTPException(422,gate)
 c.status="Committed";c.committed_at=datetime.utcnow();audit(db,cid,"COMMITTED",{"human_confirmed":True});db.commit();return {"status":"Committed"}
