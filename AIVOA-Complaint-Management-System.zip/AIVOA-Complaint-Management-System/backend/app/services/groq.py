"""Groq structured-output adapter. No API key or model is embedded in source."""
import json
import httpx
from ..config import settings
from ..schemas import ComplaintFields

FIELDS = list(ComplaintFields.model_fields)
async def extract_complaint(text: str) -> ComplaintFields:
    if not settings.groq_api_key:
        raise RuntimeError('GROQ_API_KEY is not configured')
    prompt = ('Extract only explicit pharmaceutical complaint facts. Return JSON only with these keys: '
              + ', '.join(FIELDS) + '. Use null for absent values; never infer facts. Complaint:\n' + text)
    headers = {'Authorization': f'Bearer {settings.groq_api_key}'}
    body = {'model': settings.groq_model, 'messages':[{'role':'user','content':prompt}], 'temperature':0, 'response_format':{'type':'json_object'}}
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.post('https://api.groq.com/openai/v1/chat/completions', headers=headers, json=body)
        response.raise_for_status()
    try:
        payload = json.loads(response.json()['choices'][0]['message']['content'])
        return ComplaintFields.model_validate(payload)
    except (KeyError, ValueError) as exc:
        raise RuntimeError('Groq returned malformed structured output') from exc
