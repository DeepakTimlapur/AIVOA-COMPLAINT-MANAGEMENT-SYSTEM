import re
from ..schemas import ComplaintFields, FieldPatch
def intent(message:str)->str:
    m=message.lower()
    if any(x in m for x in ("batch number is","quantity is","correct","sorry,")): return "UPDATE_FIELD"
    if "commit" in m: return "COMMIT_REQUEST"
    if "extract" in m: return "EXTRACT_COMPLAINT"
    if "risk" in m: return "RISK_ASSESSMENT"
    if "complete" in m or "missing" in m: return "COMPLETENESS_CHECK"
    if "duplicate" in m: return "DUPLICATE_CHECK"
    if "root cause" in m: return "ROOT_CAUSE"
    if "capa" in m or "corrective" in m or "preventive" in m: return "CAPA"
    if "summary" in m: return "SUMMARY"
    return "ASK_QUESTION"
def update_patch(message:str)->FieldPatch:
    updates={}; m=re.search(r"batch(?:\s+(?:number|lot))?\s+(?:is|=)\s*([A-Za-z0-9-]+)",message,re.I)
    if m: updates["batch_lot_number"]=m.group(1)
    q=re.search(r"(?:affected\s+)?quantity\s+(?:is|=)\s*(\d+)\s*([A-Za-z]+)?",message,re.I)
    if q:
        updates["affected_quantity"]=int(q.group(1))
        if q.group(2): updates["affected_quantity_unit"]=q.group(2).lower()
    return FieldPatch(updates=ComplaintFields(**updates),response="I prepared a patch for the explicitly supplied fields.")
