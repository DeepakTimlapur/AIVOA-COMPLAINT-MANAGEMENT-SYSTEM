from ..schemas import ComplaintFields
REQUIRED = ("product_name", "complaint_description")
def completeness(c: ComplaintFields|dict):
    data = c.model_dump() if hasattr(c, "model_dump") else c
    missing=[f for f in REQUIRED if not data.get(f)]
    if not data.get("batch_lot_number"): missing.append("batch_lot_number (or QA acknowledgement unavailable)")
    return {"completeness_score": round((3-len(missing))*100/3, 1), "missing_fields":missing}
def risk(c: ComplaintFields|dict):
    d=c.model_dump() if hasattr(c,"model_dump") else c; text=" ".join(str(d.get(x) or "") for x in ("complaint_description","complaint_category","structured_defect_summary")).lower(); score=0; signals=[]
    for word, points, label in (("contamin",45,"contamination"),("foreign matter",45,"foreign matter"),("patient",30,"patient impact"),("discolor",20,"appearance defect"),("broken",15,"tablet breakage")):
        if word in text: score+=points; signals.append(label)
    if d.get("batch_lot_number"): score+=10; signals.append("batch identified")
    if (d.get("affected_quantity") or 0)>=50: score+=10; signals.append("material quantity")
    score=min(score,100); severity="High" if score>=45 else "Medium" if score>=20 else "Low"
    action={"High":"Quarantine/contain affected material and begin QA investigation.","Medium":"QA triage and batch record review recommended.","Low":"Record and review during routine QA triage."}[severity]
    return {"score":score,"suggested_severity":severity,"suggested_next_action":action,"initial_risk_assessment":f"Rule-based {severity.lower()} risk ({score}/100): {', '.join(signals) or 'limited explicit risk signals'}. AI advice requires QA review.","signals":signals}
def commit_eligibility(c):
    d=c.model_dump() if hasattr(c,"model_dump") else c; missing=[x for x in REQUIRED if not d.get(x)]
    if not d.get("batch_lot_number"): missing.append("batch_lot_number or documented unavailable acknowledgement")
    return {"eligible":not missing,"blocking_fields":missing}
