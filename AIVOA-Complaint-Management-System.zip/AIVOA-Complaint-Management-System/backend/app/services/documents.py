"""Safe, text-only document intake. Uploaded bytes are never executed or persisted."""
from __future__ import annotations
from email import policy
from email.parser import BytesParser
from io import BytesIO
from pathlib import PurePath
from pypdf import PdfReader
from docx import Document

MAX_UPLOAD_BYTES = 10 * 1024 * 1024
SUPPORTED = {".pdf", ".docx", ".txt", ".eml"}
MIMES = {
    ".pdf": {"application/pdf"},
    ".docx": {"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/octet-stream"},
    ".txt": {"text/plain", "application/octet-stream"},
    ".eml": {"message/rfc822", "application/octet-stream"},
}
class DocumentError(ValueError): pass

def safe_extension(filename: str) -> str:
    name = PurePath(filename or "").name
    if name != filename or not name or "\x00" in name:
        raise DocumentError("Unsafe filename")
    ext = PurePath(name).suffix.lower()
    if ext not in SUPPORTED: raise DocumentError("Unsupported file type. Upload PDF, DOCX, TXT, or EML.")
    return ext

def validate_upload(filename: str, content_type: str | None, content: bytes) -> str:
    ext = safe_extension(filename)
    if len(content) > MAX_UPLOAD_BYTES: raise DocumentError("File exceeds the 10 MB limit.")
    if content_type and content_type.split(';')[0].lower() not in MIMES[ext]:
        raise DocumentError("File MIME type does not match its extension.")
    return ext

def extract_text(filename: str, content_type: str | None, content: bytes) -> str:
    ext = validate_upload(filename, content_type, content)
    try:
        if ext == '.txt': text = content.decode('utf-8-sig')
        elif ext == '.docx': text = '\n'.join(p.text for p in Document(BytesIO(content)).paragraphs)
        elif ext == '.pdf':
            text = '\n'.join(page.extract_text() or '' for page in PdfReader(BytesIO(content)).pages)
            if not text.strip(): raise DocumentError('This PDF appears scanned or image-only. OCR is not supported in this version.')
        else:
            message = BytesParser(policy=policy.default).parsebytes(content)
            chunks = [message.get('subject', ''), message.get_body(preferencelist=('plain',)).get_content() if message.get_body(preferencelist=('plain',)) else '']
            text = '\n'.join(str(x) for x in chunks)
    except DocumentError: raise
    except Exception as exc: raise DocumentError(f'Unable to parse {ext[1:].upper()} document.') from exc
    if not text.strip(): raise DocumentError('The document contains no extractable text.')
    return text.strip()
