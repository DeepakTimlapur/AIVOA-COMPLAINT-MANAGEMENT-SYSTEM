from difflib import SequenceMatcher
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Complaint, ComplaintAnalysis
from ..schemas import ComplaintOut

def duplicates(db: Session, complaint: Complaint) -> list[dict]:
    """Database-first candidate filter, then deterministic text similarity."""
    candidates = db.scalars(select(Complaint).where(Complaint.id != complaint.id, Complaint.status == 'Committed')).all()
    matches = []
    for item in candidates:
        facts = []
        if complaint.product_name and complaint.product_name == item.product_name: facts.append('same product')
        if complaint.batch_lot_number and complaint.batch_lot_number == item.batch_lot_number: facts.append('same batch')
        if complaint.customer_name and complaint.customer_name == item.customer_name: facts.append('same customer')
        if complaint.complaint_category and complaint.complaint_category == item.complaint_category: facts.append('same category')
        if not facts: continue
        similarity = SequenceMatcher(None, complaint.complaint_description or '', item.complaint_description or '').ratio()
        confidence = round(min(1, len(facts) * .25 + similarity * .5), 2)
        if confidence >= .25: matches.append({'complaint_id':item.id, 'confidence':confidence, 'reason':', '.join(facts)})
    return sorted(matches, key=lambda x:x['confidence'], reverse=True)

def recommendations(c: Complaint) -> dict:
    text = (c.complaint_description or '').lower()
    root = [{'hypothesis':'Possible material, packaging, or process-related quality deviation','evidence':'Grounded only in reported complaint details; investigation is required.','confidence':'Low','investigation_areas':['batch record','retains','packaging line']}]
    capa = {'containment':['Segregate affected stock where traceable.'], 'investigation':['Review complaint evidence and batch documentation.'], 'corrective_action':['Define after confirmed root cause.'], 'preventive_action':['Define after trend review.'], 'effectiveness_check':['QA approval required before closure.']}
    if 'contamin' in text: root[0]['investigation_areas'].append('foreign matter controls')
    return {'root_cause_hypotheses':root, 'capa_recommendations':capa, 'disclaimer':'Requires QA Review; hypotheses and recommendations are advisory.'}

def summary(c: Complaint) -> str:
    parts=[]
    if c.customer_name: parts.append(f'{c.customer_name} reported')
    if c.product_name: parts.append(c.product_name)
    if c.product_strength_grade: parts.append(c.product_strength_grade)
    if c.batch_lot_number: parts.append(f'batch {c.batch_lot_number}')
    if c.complaint_description: parts.append(f'Issue: {c.complaint_description}')
    return '. '.join(parts) or 'No known complaint facts are available.'

def persist_analysis(db: Session, complaint_id: int, **values) -> ComplaintAnalysis:
    row = db.scalars(select(ComplaintAnalysis).where(ComplaintAnalysis.complaint_id == complaint_id)).first()
    if not row: row=ComplaintAnalysis(complaint_id=complaint_id); db.add(row)
    for key,value in values.items(): setattr(row,key,value)
    return row
