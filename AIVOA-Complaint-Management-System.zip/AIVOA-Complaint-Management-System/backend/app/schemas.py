from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from typing import Literal
class ComplaintFields(BaseModel):
    complaint_source: str|None=None; customer_name: str|None=None; product_name: str|None=None; batch_lot_number: str|None=None
    product_strength_grade: str|None=None; affected_quantity: int|None=Field(default=None, ge=0); affected_quantity_unit: str|None=None
    manufacturing_date: str|None=None; expiry_date: str|None=None; originating_site_block: str|None=None; impacted_non_product_materials: str|None=None
    structured_defect_summary: str|None=None; complaint_category: str|None=None; complaint_description: str|None=None; complaint_date: str|None=None
    initial_severity: str|None=None; priority: str|None=None
class ComplaintCreate(ComplaintFields): pass
class ComplaintPatch(ComplaintFields): pass
class ComplaintOut(ComplaintFields):
    id:int; status:str; created_at:datetime; updated_at:datetime; committed_at:datetime|None=None
    model_config=ConfigDict(from_attributes=True)
class ExtractRequest(BaseModel): source_text:str=Field(min_length=3, max_length=50000)
class CopilotRequest(BaseModel): message:str=Field(min_length=1, max_length=10000)
class CommitRequest(BaseModel): confirm: Literal[True]
class FieldPatch(BaseModel):
    updates: ComplaintFields
    intent: str = "UPDATE_FIELD"
    response: str = ""
