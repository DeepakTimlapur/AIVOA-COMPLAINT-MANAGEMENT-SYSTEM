# AIVOA Complaint Management

An AI-assisted, human-controlled pharmaceutical complaint intake and QMS ledger. React/Redux owns the working form; FastAPI owns validation, commit gating and audit events; two LangGraph workflows use Groq for structured extraction and Copilot assistance.

## Quick start

1. `copy backend/.env.example backend/.env` and add `GROQ_API_KEY` for live LLM extraction.
2. Start PostgreSQL and set `DATABASE_URL=postgresql+psycopg://user:password@localhost:5432/aivoa`. SQLite is only a local-development fallback.
3. `cd backend && python -m venv .venv && .venv\Scripts\pip install -r requirements.txt && .venv\Scripts\alembic upgrade head && .venv\Scripts\uvicorn app.main:app --reload`
4. `cd frontend && pnpm install && pnpm dev`

The API is documented at `/docs`. Run backend tests with `pytest`; run the frontend checks with `npm test`.

Document intake accepts PDF, DOCX, TXT, and EML files up to 10 MB through `POST /api/complaints/extract-document`. It validates the filename and MIME type and never executes or retains the uploaded payload. Image-only PDFs return an OCR-not-supported error.

Analysis endpoints persist deterministic completeness, risk, and duplicate results; the recommendations endpoint stores QA-review-only root-cause hypotheses and CAPA suggestions.

## Verification

Backend: `cd backend && .venv\Scripts\python -m pytest tests -q`.

Frontend: `cd frontend && node node_modules\vitest\vitest.mjs run`, then `node node_modules\vite\bin\vite.js build`.

`frontend/pnpm-workspace.yaml` explicitly permits only Vite's `esbuild` dependency build. If pnpm still asks for approval, run `pnpm approve-builds`, select `esbuild`, then rerun `pnpm install`.

## Production services

Set `GROQ_API_KEY` and optional `GROQ_MODEL` (defaults to `gemma2-9b-it`) to enable real structured extraction. Without a key, the system stores only source text and explicitly warns that no AI facts were inferred. PostgreSQL must be available before treating the application as production verified; this workspace did not have a running Docker daemon or PostgreSQL service at the last verification.

## Design and limitations

Groq is invoked through its OpenAI-compatible API with `GROQ_MODEL=gemma2-9b-it`. If it is unavailable, the API returns an explicit AI service warning and keeps deterministic completeness/risk functions available; it never fabricates an extraction. OCR for scanned PDFs is intentionally unsupported.

See [architecture](docs/architecture.md), [demo script](docs/demo-script.md), [QMS research](docs/qms-research.md), and [interview questions](docs/interview-questions.md).
