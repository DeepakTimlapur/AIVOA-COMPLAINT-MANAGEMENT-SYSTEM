import {describe,it,expect} from 'vitest'
import {renderToStaticMarkup} from 'react-dom/server'
import {Provider} from 'react-redux'
import {store} from './store'
import {App} from './main'
describe('complaint UI',()=>{
 it('renders the intake, upload, grouped form, Copilot and commit controls',()=>{
  const html=renderToStaticMarkup(<Provider store={store}><App/></Provider>)
  expect(html).toContain('Log Customer Complaint')
  expect(html).toContain('Upload PDF, DOCX, TXT or EML')
  expect(html).toContain('AI Complaint Intake Assistant')
  expect(html).toContain('Commit to QMS Ledger')
 })
})
