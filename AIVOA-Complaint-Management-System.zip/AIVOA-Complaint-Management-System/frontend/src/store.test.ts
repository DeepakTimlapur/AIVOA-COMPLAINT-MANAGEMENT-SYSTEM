import {describe,it,expect} from 'vitest'
import {complaintReducer,merge} from './store'
describe('complaint patch merging',()=>{
 it('keeps unrelated form fields when a Copilot patch arrives',()=>{
  const before={status:'Review Required',product_name:'Amoxicillin Capsules',complaint_description:'Discolored capsules',batch_lot_number:'OLD_BATCH',affected_quantity:20}
  const after=complaintReducer(before,merge({batch_lot_number:'BMX240602',affected_quantity:48,affected_quantity_unit:'capsules'}))
  expect(after).toMatchObject({product_name:'Amoxicillin Capsules',complaint_description:'Discolored capsules',batch_lot_number:'BMX240602',affected_quantity:48,affected_quantity_unit:'capsules'})
 })
})
