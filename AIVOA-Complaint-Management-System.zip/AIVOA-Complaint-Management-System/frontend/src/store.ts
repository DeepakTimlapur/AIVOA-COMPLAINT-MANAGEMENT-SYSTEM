import {configureStore, createSlice, PayloadAction} from '@reduxjs/toolkit'
export type Complaint = {id?: number; status: string; [key: string]: string | number | undefined}
const complaint = createSlice({name:'complaint', initialState:{status:'Pending Triage'} as Complaint, reducers:{merge:(s,a:PayloadAction<Partial<Complaint>>)=>Object.assign(s,a.payload), reset:()=>({status:'Pending Triage'})}})
export const {merge,reset} = complaint.actions
export const complaintReducer = complaint.reducer
export const store = configureStore({reducer:{complaint:complaint.reducer}})
export type RootState = ReturnType<typeof store.getState>
