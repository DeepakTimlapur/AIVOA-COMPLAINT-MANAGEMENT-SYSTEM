# Interview questions

**Why split graphs?** Intake and conversational correction have distinct safety boundaries. **Why deterministic risk?** It is reproducible and auditable. **How do you limit hallucination?** Unknown facts remain null; only explicit user updates are patched and commit validation is server-side.
