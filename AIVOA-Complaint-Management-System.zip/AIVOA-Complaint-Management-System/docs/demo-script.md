# Demo script

Paste “Apollo Pharmacy reported discolored capsules in Amoxicillin Capsules 500 mg.” and select **Extract with AI Intake**. Review the null batch field and save. Ask: “Sorry, the batch number is BMX240602 and affected quantity is 48 capsules.” The Copilot applies only those three fields. Review the risk card, then confirm the QMS commit. The saved record becomes read-only.
