# Architecture

The data path is `React → Redux Toolkit → FastAPI → LangGraph → Groq → PostgreSQL`. Redux owns the review-time form and merges each Copilot `updates` patch into the existing object. FastAPI independently validates all data, applies deterministic gatekeeping, persists analysis/audit data, and writes ledger commits.

There are two LangGraph graphs: `extract_and_analyze_graph` for intake stages and `copilot_graph` for conversational intent/update work. This separation keeps correction requests from sharing state transitions with intake or QMS commit operations. Groq returns a Pydantic-validated structured complaint object; unavailable keys/timeouts are surfaced as warnings, never replaced by invented facts. AI is advisory; deterministic server rules control required-field completeness, numerical risk signals, duplicate matching, and commit eligibility.

Documents are accepted as transient bytes only (PDF, DOCX, TXT, EML), constrained to 10 MB and parsed as text. Image-only PDFs return an explicit unsupported-OCR error.
