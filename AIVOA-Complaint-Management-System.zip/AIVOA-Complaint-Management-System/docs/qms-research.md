# QMS notes

AI supports complaint intake but cannot make quality decisions. This design preserves human QA review, server-side validation, transparent risk signals, and an auditable event history.
